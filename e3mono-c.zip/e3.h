#ifndef E3_H
#define E3_H
typedef struct E3 E3;
/* sr 32000..63999, ch 1..8, block 1..1024 (FL uses 512). returns NULL on bad args. */
E3 *e3_new(int sr, int ch, int block);
void e3_set(E3 *e, float pitch, float stretch);   /* call before e3_needed each step */
int e3_needed(E3 *e);                              /* input frames the next e3_process wants (may be 0) */
float *e3_inbuf(E3 *e, int c, int n);              /* planar input scratch for channel c, capacity >= n */
int e3_process(E3 *e, int n);                      /* consume n frames from inbuf; 1 = block ready in outbuf */
float *e3_outbuf(E3 *e, int c);
void e3_free(E3 *e);
#endif
