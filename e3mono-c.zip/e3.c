/* e3.c -- elastique Pro V3 "mono" (CelastiqueSOLOV3) in portable C. port of web/e3core.js + web/e3track.js,
   which are bit-exact vs FL Studio 20's elastique_x64.dll. compile with -ffp-contract=off (no FMA).
   streaming API (see e3.h). memory is bounded: marks trimmed like the DLL (>1024 -> drop 128), synth input
   history dropped once it is behind the oldest reachable grain. */
#include <math.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>
#include "e3.h"
#include "e3_tables.h"     /* RAMP[16384], IMP[768], IMPD[768], WIN[1024], LPF[5], TINYFILL bits */

typedef float f32;
#define N_RAMP 0x4000
static inline int imax(int a, int b) { return a > b ? a : b; }
static inline int imin(int a, int b) { return a < b ? a : b; }
static inline f32 bits2f(uint32_t u) { f32 f; memcpy(&f, &u, 4); return f; }

/* growable float array */
typedef struct { f32 *p; int n, cap; } fvec;
static void fv_reserve(fvec *v, int cap) { if (cap > v->cap) { int c = imax(cap, v->cap * 2 + 16); v->p = (f32 *)realloc(v->p, sizeof(f32) * c); v->cap = c; } }
static void fv_append(fvec *v, const f32 *x, int n) { fv_reserve(v, v->n + n); memcpy(v->p + v->n, x, sizeof(f32) * n); v->n += n; }
static void fv_shift(fvec *v, int k) { if (k <= 0) return; if (k >= v->n) { v->n = 0; return; } memmove(v->p, v->p + k, sizeof(f32) * (v->n - k)); v->n -= k; }

/* ================================================================ f64 FFT (complex radix-2, real via N/2 trick) */
typedef struct { int n; double *cs, *sn; int *rev; double *re, *im; } FFT;   /* complex size n */
static void fft_init(FFT *f, int n) {
  f->n = n; f->cs = malloc(sizeof(double) * n / 2); f->sn = malloc(sizeof(double) * n / 2); f->rev = malloc(sizeof(int) * n);
  f->re = malloc(sizeof(double) * n); f->im = malloc(sizeof(double) * n);
  int bits = 0; while ((1 << bits) < n) bits++;
  for (int i = 0; i < n; i++) { int r = 0, x = i; for (int b = 0; b < bits; b++) { r = (r << 1) | (x & 1); x >>= 1; } f->rev[i] = r; }
  for (int i = 0; i < n / 2; i++) { f->cs[i] = cos(2 * M_PI * i / n); f->sn[i] = sin(2 * M_PI * i / n); }
}
static void fft_run(FFT *f, int inverse) {
  int n = f->n; double *re = f->re, *im = f->im;
  for (int i = 0; i < n; i++) { int j = f->rev[i]; if (j > i) { double t = re[i]; re[i] = re[j]; re[j] = t; t = im[i]; im[i] = im[j]; im[j] = t; } }
  for (int size = 2; size <= n; size <<= 1) {
    int half = size >> 1, step = n / size;
    for (int s = 0; s < n; s += size) for (int k = 0; k < half; k++) {
      double wr = f->cs[k * step], wi = inverse ? f->sn[k * step] : -f->sn[k * step];
      int a = s + k, b = a + half; double tr = re[b] * wr - im[b] * wi, ti = re[b] * wi + im[b] * wr;
      re[b] = re[a] - tr; im[b] = im[a] - ti; re[a] += tr; im[a] += ti;
    }
  }
}
/* real FFT of length N = 2M via one complex FFT of size M (f64), output IPP perm format as f32 */
typedef struct { int N; FFT c; double *tc, *ts; } RFFT;
static void rfft_init(RFFT *r, int N) {
  r->N = N; fft_init(&r->c, N / 2); r->tc = malloc(sizeof(double) * N / 2); r->ts = malloc(sizeof(double) * N / 2);
  for (int k = 0; k < N / 2; k++) { r->tc[k] = cos(2 * M_PI * k / N); r->ts[k] = sin(2 * M_PI * k / N); }
}
static void rfft_perm(RFFT *r, const f32 *x, f32 *o) {
  int N = r->N, M = N / 2; double *re = r->c.re, *im = r->c.im;
  for (int i = 0; i < M; i++) { re[i] = x[2 * i]; im[i] = x[2 * i + 1]; }
  fft_run(&r->c, 0);
  /* X[k] = (Z[k] + conj Z[M-k])/2 + e^{-2pi i k/N} (Z[k] - conj Z[M-k])/(2i) */
  o[0] = (f32)(re[0] + im[0]); o[1] = (f32)(re[0] - im[0]);
  for (int k = 1; k < M; k++) {
    double zr = re[k], zi = im[k], wr2 = re[M - k], wi2 = -im[M - k];
    double er = 0.5 * (zr + wr2), ei = 0.5 * (zi + wi2), dr = 0.5 * (zr - wr2), di = 0.5 * (zi - wi2);
    /* (dr + i di)/i = di - i dr ; times (c - i s) */
    double c = r->tc[k], s = r->ts[k], tr = di, ti = -dr;
    double xr = er + (tr * c + ti * s), xi = ei + (ti * c - tr * s);
    o[2 * k] = (f32)xr; o[2 * k + 1] = (f32)xi;
  }
}
/* unscaled inverse (= N * idft) from perm input */
static void rifft_perm(RFFT *r, const f32 *p, f32 *o) {
  int N = r->N, M = N / 2; double *re = r->c.re, *im = r->c.im;
  /* build Z[k] = (X[k] + conj X[M-k]) + i e^{+2pi i k/N}(X[k] - conj X[M-k]) , k < M */
  for (int k = 0; k < M; k++) {
    double xr, xi, yr, yi;
    if (k == 0) { xr = p[0]; xi = 0; yr = p[1]; yi = 0; }         /* X[0], X[M] */
    else { xr = p[2 * k]; xi = p[2 * k + 1]; yr = p[2 * (M - k)]; yi = -p[2 * (M - k) + 1]; }
    double er = xr + yr, ei = xi + yi, dr = xr - yr, di = xi - yi;
    double c = r->tc[k], s = r->ts[k];
    double tr = dr * c - di * s, ti = dr * s + di * c;           /* e^{+i..} * d */
    re[k] = er - ti; im[k] = ei + tr;                             /* + i*t */
  }
  fft_run(&r->c, 1);
  for (int i = 0; i < M; i++) { o[2 * i] = (f32)re[i]; o[2 * i + 1] = (f32)im[i]; }
}

/* ================================================================ tracker (CPitchTrack) */
#define SR_T 11025
#define NFFT 8192
#define HOP 128
#define FRAME 1024
typedef struct {
  int Nwing, Npc, half, Xoff, Xp, Xread, hist, size, ptr, Nx, first; double Time; f32 *buf;
} Resampler;
static void rs_init(Resampler *r) {
  r->Nwing = 768; r->Npc = 256; int v6 = ((r->Nwing / 128) + 2) >> 1; r->half = v6;
  r->Xoff = r->Xp = r->Xread = 2 * v6; r->Time = 2 * v6; r->hist = 1000 * v6 + 1; r->size = r->hist + (2 * v6 + 0x4000);
  r->buf = calloc(r->size + r->hist, sizeof(f32)); r->ptr = r->hist; r->Nx = 0; r->first = 1;
}
static int rs_hop(Resampler *r, int sr, int nout) {
  f32 v4 = (f32)sr / (f32)SR_T, prod = (f32)nout * v4;
  if (r->first) { double v5 = v4 >= 1 ? v4 : 1, t = r->half * v5 + 1, v8 = r->Xoff > t ? r->Xoff : t; double v11 = ceil(prod + v8); return v11 >= 0 ? (int)v11 : 0; }
  double v16 = ceil((f32)(prod - (f32)r->Nx)); return v16 >= 0 ? (int)v16 : 0;
}
static int rs_filt(Resampler *r, f32 factor, int nx, f32 gain, f32 *out) {
  f32 v11 = 1.0f / factor; double inc = v11;
  f32 v7 = factor * 256.0f; if (v7 > 256.0f) v7 = 256.0f;
  int dhb = (int)((double)(v7 * 128.0f) + 0.5), lim = 100 * nx, k = 0, cnt = 0;
  const int Nw = r->Nwing << 7, Nr = Nw - 128; const f32 *X = r->buf; int base = r->ptr; const f32 c = 0.0078125f;
  while ((int)floor((f32)((f32)((f32)k * v11) * 100.0f) + 0.5f) < lim) {
    double tm = r->Time; r->Time = r->Time + inc; k++;
    int64_t t = (int64_t)(tm * 32768.0); int idx = (int)(t >> 15), frac = (int)(t & 0x7FFF);
    f32 left = 0, right = 0; int ph = (int)(((int64_t)dhb * frac) >> 15), j = 0;
    while (ph < Nw) { int ti = ph >> 7; f32 co = (f32)((f32)((f32)(ph & 0x7F) * c) * IMPD[ti]) + IMP[ti]; left = left + co * X[base + idx - j]; ph += dhb; j++; }
    int rf = (int)((-t) & 0x7FFF); ph = (int)(((int64_t)rf * dhb) >> 15); if (rf == 0) ph += dhb; j = 0;
    while (ph < Nr) { int ti = ph >> 7; f32 co = (f32)((f32)((f32)(ph & 0x7F) * c) * IMPD[ti]) + IMP[ti]; right = right + co * X[base + idx + 1 + j]; ph += dhb; j++; }
    out[cnt++] = (right + left) * gain;
  }
  return cnt;
}
static int rs_process(Resampler *r, const f32 *x, int n, int sr, f32 *out) {
  f32 factor = (f32)SR_T / (f32)sr, v13 = 1.0f / factor, v14 = v13 >= 1 ? v13 : 1.0f;
  f32 v15 = (f32)r->half, v16 = (f32)r->Xoff;
  if (v16 <= (f32)(v15 * v14) + 1.0f) v16 = (f32)(v15 * (v13 >= 1 ? v13 : 1.0f)) + 1.0f;
  int nX = (int)v16;
  if (nX != r->Xoff) { int d = nX - r->Xoff; r->Xp += d; r->Xread += d; r->ptr -= d; r->Time = d + r->Time; }
  r->Xoff = nX;
  f32 gain = factor < 1 ? factor * 0.99000001f : 0.99000001f;
  memcpy(r->buf + r->ptr + r->Xp + r->Nx, x, sizeof(f32) * n);
  r->Nx += n; int v18 = r->Nx, nx = v18;
  if (r->first) { r->first = 0; nx = v18 - r->Xoff; }
  r->Nx = r->Xp + v18;
  int cnt = rs_filt(r, factor, nx, gain, out);
  int Xo = r->Xoff;
  r->Xread += nx; r->Time = r->Time - nx; r->Nx -= 2 * Xo + nx;
  int v28 = (int)(r->Time - Xo);
  if (v28) { r->Xread += v28; r->Time = r->Time - v28; }
  int lo = -Xo, hi = 3 * Xo + r->Nx - r->Xread + nx, sh = r->Xread - Xo;
  if (hi > lo) memmove(r->buf + r->ptr + lo, r->buf + r->ptr + lo + sh, sizeof(f32) * (hi - lo));
  r->Xp = nx + 3 * Xo - r->Xread; r->Xread = Xo;
  return cnt;
}

typedef struct {
  RFFT rf; f32 *b88, *spec, *mag0, *b112, *P, *M, *b104, *acf, *mag, *comb, *hps, *dst;
  int i8, i12, i16, hiLag, loLag, flag172; f32 s32, s36, rms, rmsPrev, drms, thr168; f32 H[12];
} TAnalysis;
static void ta_init(TAnalysis *a) {
  int n = NFFT; memset(a, 0, sizeof *a); rfft_init(&a->rf, n);
  f32 **bufs[] = { &a->b88, &a->spec, &a->b112, &a->P, &a->b104, &a->acf, &a->mag, &a->comb, &a->dst };
  for (unsigned i = 0; i < sizeof bufs / sizeof *bufs; i++) *bufs[i] = calloc(n, sizeof(f32));
  a->mag0 = calloc(n / 2, sizeof(f32)); a->M = calloc(n / 2, sizeof(f32)); a->hps = calloc(n / 2, sizeof(f32));
  a->hiLag = (int)((f32)(44 * n) * 0.00012207031f); a->loLag = (int)((f32)(28 * n) * 0.00012207031f);
}
static void magperm(const f32 *p, int n2, f32 *m) {
  for (int k = 0; k < n2; k++) {
    f32 re = k == 0 ? p[0] : p[2 * k], im = k == 0 ? 0 : p[2 * k + 1];
    f32 s = re * re + im * im;
    m[k] = (s > 0 && s < 1.1754944e-38f) ? INFINITY : sqrtf(s);
  }
}
static int argmax0(const f32 *a, int lo, int hi) { f32 m = 0; int bi = 0; for (int i = lo; i < hi; i++) { f32 v = a[i]; if (v > m) { m = v; bi = i - lo; } } return bi; }
static f32 maxFrom(const f32 *a, int lo, int hi, f32 floor_) { f32 m = -INFINITY; for (int i = lo + 1; i < hi; i++) { f32 v = a[i]; if (v > m) m = v; } return m > floor_ ? m : floor_; }
static f32 refine(double a0, double a1, double a2) {
  double v4 = (a1 - a0) / 30.0, C = ((a2 - a0) - 60.0 * v4) / (60.0 * 30.0), prev = -1.0000000195414814e-25, x = 0.0;
  for (;;) { double cur = (x * C) * (x - 30.0) + (x * v4 + a0); if (prev >= cur) return (f32)((x - 1.0) / 30.0); prev = cur; x += 1.0; if (!(60.0 >= x)) return 0; }
}
static void ta_decide(TAnalysis *a, f32 *out) {
  int n = NFFT, n2 = n >> 1; f32 *hps = a->hps, *mag = a->mag, *H = a->H;
  int v2 = a->i8; f32 v6 = H[11], v8 = H[0];
  if (v6 > 0 && v8 > 0) {
    f32 fq = (f32)(11025 * v2) / (f32)n;
    if ((double)fq > (double)(f32)(v8 + v6) * 1.8 * 0.5 || a->flag172) {
      int v9 = a->i16; a->flag172 = 0;
      if (v9 > a->hiLag && v2 * 0.3 >= fabs(v2 - v9 * 2.0)) { v2 = v9; a->flag172 = 1; }
    } else a->flag172 = 0;
  }
  f32 v13 = (f32)(11025 * v2), v14 = v13 / (f32)n; double thr = (double)hps[v2] * 0.25;
  int v11 = v2; while (v11 > 0 && !(thr > hps[v11])) v11--;
  int v20 = v2; while (v20 < n2 && !(thr > hps[v20])) v20++;
  int v29 = (int)((f32)(n * 25) / 11025.0f), v25 = imax(v2 >> 3, v29);
  f32 s36 = (f32)(v20 - v11) / (f32)v25;
  int v26 = (int)((f32)(n * -25) / 11025.0f), v31 = imax(v2 - v29, 1), v33 = imin(v2 - v26, n2);
  double v36 = hps[v2], v37 = 1.0 / v36; for (int i = v31; i < v33; i++) v37 = v37 * hps[i];
  double g = v36 / pow(v37, 1.0 / (v33 - v31));
  double v41 = (f32)g; if (v41 > 2) v41 = 2;
  s36 = (f32)(2 - v41) + s36; a->s36 = s36;
  int uvForced = (s36 > 1 && ((double)v6 * 0.75 > v14 || (double)v14 * 0.75 > v6) && v6 > 0) || v2 <= 0;
  f32 s32;
  if (!uvForced) {
    f32 v7 = 0; for (int i = v2; i < n2; i++) v7 = v7 + mag[i];
    f32 v48 = v7 / (f32)(n2 - v2); s32 = 0; int v47 = v2;
    if (v2 < (n >> 2)) { f32 acc = 0; while (v47 < (n >> 2)) { acc = acc + mag[v47]; v47 += v2; } s32 = acc; }
    if (1e-7f >= (f32)(a->rms * a->rms)) s32 = 1;
    else if (v47 == v2) s32 = s32 / v48;
    else s32 = s32 / (f32)((f32)(v47 / v2 - 1) * v48);
  } else s32 = 1;
  a->s32 = s32;
  f32 db = (f32)(f32)log((double)s32) * 4.3429446f; out[1] = db;
  f32 v54 = (f32)n, v55 = v13 / v54;
  int gotoB; if (!(3.5f > db)) gotoB = 1; else if (160 > v55) gotoB = 0; else gotoB = 1;
  int voiced = 0; if (gotoB) { if (!(a->thr168 > db)) voiced = 1; else if (!(v55 >= 160)) voiced = 1; }
  if (voiced) {
    f32 r = refine(mag[v2 - 1], mag[v2], mag[v2 + 1]);
    f32 f = (f32)((f32)((f32)(r + (f32)v2) - 1.0f) * 11025.0f) / v54;
    for (int i = 9; i >= 1; i--) H[i] = H[i - 1];
    H[0] = H[10]; H[10] = out[0]; H[11] = out[0]; out[0] = f;
  } else {
    f32 v56 = out[0];
    if ((double)fabsf(v56 - v55) > (double)v56 * 0.2) v2 = (int)((f32)((f32)(v54 * H[5]) / 11025.0f) + 0.5f);
    f32 v3 = 0; if (v2 > 0) v3 = (f32)(refine(mag[v2 - 1], mag[v2], mag[v2 + 1]) + (f32)v2) - 1.0f;
    H[11] = v56; out[0] = (f32)(v3 * 11025.0f) / v54; out[1] = 0;
  }
  out[4] = a->s36; out[2] = a->rms; out[3] = a->drms;
}
static void ta_analyze(TAnalysis *a, const f32 *frame, f32 *out) {
  int n = NFFT, n2 = n >> 1;
  double s = 0; for (int i = 0; i < FRAME; i++) { f32 v = frame[i]; s += v > 1e-24 ? (double)(f32)(v * v) : 1e-24; }
  f32 v7 = sqrtf((f32)s / (f32)FRAME); a->rms = v7;
  a->drms = (f32)(v7 - a->rmsPrev) / (f32)(v7 + 1e-32f); a->rmsPrev = v7;
  memset(a->b88, 0, sizeof(f32) * n); for (int i = 0; i < FRAME; i++) a->b88[i] = frame[i] * WIN[i];
  rfft_perm(&a->rf, a->b88, a->spec); magperm(a->spec, n2, a->mag0);
  f32 *b112 = a->b112, *mag0 = a->mag0;
  int lo = imax(6, (int)((f32)((f32)(2 * n2) * 25.0f) / 11025.0f)), hi = (int)((f32)((f32)(2 * n2) * 200.0f) / 11025.0f);
  memset(b112, 0, sizeof(f32) * n); f32 tf = bits2f(TINYFILL_BITS); for (int i = 0; i < lo; i++) b112[i] = tf;
  for (int k = lo; k < hi; k++) if (mag0[k] > mag0[k - 1] && mag0[k] >= mag0[k + 1]) for (int i = k - 4; i < k + 5; i++) b112[i] = mag0[i];
  for (int i = hi - 4; i < n2; i++) b112[i] = mag0[i];
  rfft_perm(&a->rf, b112, a->P); magperm(a->P, n2, a->M);
  f32 *b104 = a->b104; memset(b104, 0, sizeof(f32) * n); b104[0] = a->M[0] * a->M[0];
  for (int k = 1; k < n2; k++) b104[2 * k] = a->M[k] * a->M[k];
  rifft_perm(&a->rf, b104, a->acf);
  f32 inv88 = 1.0f / maxFrom(mag0, 0, n2, 1e-25f);
  f32 *mag = a->mag; for (int k = 0; k < n2; k++) mag[k] = mag0[k] * inv88; for (int k = n2; k < n; k++) mag[k] = a->spec[k];
  f32 inv112 = 1.0f / maxFrom(a->acf, 0, n2, 1e-25f);
  f32 *comb = a->comb; memset(comb, 0, sizeof(f32) * n);
  for (int k = 0; k < n2; k++) comb[k] = (f32)(mag[k] * 0.25f) + (f32)(inv112 * a->acf[k]);
  int v16 = 0; for (int k = 1; k < n >> 3; k++) if (comb[k + 1] > comb[k] && comb[k - 1] > comb[k]) { v16 = k; break; }
  int v27 = (int)((f32)((f32)n * 25.0f) / 11025.0f); if (v16 > v27) v27 = v16;
  memset(comb, 0, sizeof(f32) * v27);
  a->i12 = v27 + argmax0(comb, v27, n >> 2);
  memcpy(b104, comb, sizeof(f32) * n2);
  f32 *hps = a->hps; for (int i = 0; i < n2; i++) hps[i] = 2 * b104[i];
  for (int h = 2; h <= 3; h++) {
    int q = n2 / h; f32 c015 = 0.15000001f, hf = (f32)h;
    for (int i = 0; i < q; i++) hps[i] = (f32)((b104[i * h] + c015) / hf) * hps[i];
    f32 cq = c015 / hf; for (int i = q; i < n2; i++) hps[i] = cq * hps[i];
  }
  a->i8 = argmax0(hps, 0, n2);
  f32 *dst = a->dst; memset(dst, 0, sizeof(f32) * n); int kmax = (4000 * n) / 11025;
  for (int k = a->loLag; k < kmax; k++) {
    int nj = imin(9, (n - 1) / k); f32 sm = 0;
    for (int j = 1; j <= nj; j++) sm = sm + (f32)(comb[j * k] * 31.0f) / (f32)(30 + j);
    f32 kf = (f32)k;
    sm = sm - comb[(int)(kf * 0.5f)] * 0.25f;
    sm = sm - comb[(int)(kf * 0.66659999f)] * 0.1f;
    sm = sm - comb[(int)(kf * 0.33329999f)] * 0.1f;
    dst[k] = sm / (f32)nj;
  }
  a->i16 = argmax0(dst, 0, n2);
  ta_decide(a, out);
}

typedef struct {
  int sr; Resampler rs; f32 lx1, lx2, ly1, ly2; TAnalysis an;
  f32 ring[0x4000]; int wr, rd; f32 out[5], frame[FRAME], *tmp; int tmpcap;
} Track;
static void tr_init(Track *t, int sr) {
  memset(t, 0, sizeof *t); t->sr = sr; rs_init(&t->rs); ta_init(&t->an);
  t->rd = (HOP + 0x4000 - FRAME) & 0x3FFF; t->tmpcap = 0x8000; t->tmp = malloc(sizeof(f32) * t->tmpcap);
}
static int tr_hop(Track *t) { return rs_hop(&t->rs, t->sr, HOP); }
static void tr_feed(Track *t, const f32 *x, int n, f32 *res) {
  int m = rs_process(&t->rs, x, n, t->sr, t->tmp);
  const f32 b0 = LPF[0], b1 = LPF[1], b2 = LPF[2], a1 = LPF[3], a2 = LPF[4], tiny = 1e-24f;
  for (int i = 0; i < m; i++) {
    f32 xi = t->tmp[i];
    f32 y = (f32)((f32)((f32)(t->lx1 * b1) + (f32)(xi * b0)) + (f32)(t->lx2 * b2)) + (f32)((f32)((f32)(t->ly2 * a2) + (f32)(t->ly1 * a1)) + tiny);
    t->lx2 = t->lx1; t->lx1 = xi; t->ly2 = t->ly1; t->ly1 = y;
    t->ring[t->wr] = y; t->wr = (t->wr + 1) & 0x3FFF;
  }
  for (int i = 0; i < 5; i++) res[i] = 0;
  while (((t->wr - t->rd) & 0x3FFF) >= FRAME) {
    for (int i = 0; i < FRAME; i++) t->frame[i] = t->ring[(t->rd + i) & 0x3FFF];
    ta_analyze(&t->an, t->frame, t->out); memcpy(res, t->out, sizeof(f32) * 5);
    t->rd = (t->rd + HOP) & 0x3FFF;
  }
}

/* ================================================================ PSOLA analysis (marks) */
typedef struct {
  Track *T; f32 sr; int c80, c156, c88, c92, c96, c100, kkfN, hop184;
  fvec buf, tbuf; int p124, p144, p176; f32 f244, f296, f300;
  int *marks; f32 *f8; int nm, cap, mbase;          /* marks[] holds absolute positions; mbase = #trimmed */
  f32 firZ, iirY, iirC3, iirC4, pk232, pk236; int fl272, fl276;
} Ana;
static void an_init(Ana *a, Track *T, f32 sr) {
  memset(a, 0, sizeof *a); a->T = T; a->sr = sr;
  a->c80 = 2048; a->c156 = 32; a->c88 = 2048; a->c92 = 1024; a->c96 = 512; a->c100 = 512;
  a->f244 = 2; a->cap = 2048; a->marks = malloc(sizeof(int) * a->cap); a->f8 = malloc(sizeof(f32) * a->cap);
  a->marks[0] = 0; a->f8[0] = 0; a->nm = 1;
  a->iirC3 = 0.89999998f; a->iirC4 = 1 - a->iirC3;
}
static void an_push(Ana *a, int pos, f32 f8) {
  if (a->nm == a->cap) { a->cap *= 2; a->marks = realloc(a->marks, sizeof(int) * a->cap); a->f8 = realloc(a->f8, sizeof(f32) * a->cap); }
  a->marks[a->nm] = pos; a->f8[a->nm] = f8; a->nm++;
}
static void an_setVoiced(Ana *a, f32 P) {
  int v7 = a->c80, v21 = a->c156, v24 = (int)P;
  int v23 = 2 * v24 < 2 * v7 ? 2 * v24 : 2 * v7; if (2 * v21 > v23) v23 = 2 * v21;
  a->c88 = v23; int v25 = v23 >> 1; a->c92 = v25; a->c96 = v25 >> 1;
  double v26 = (double)P * (a->f300 == 0 ? 0.125 : 0.0625);
  int v28 = imax((int)v26, v21 >> 2); v28 = imin(v28, v25 >> 1); a->c100 = v28;
  if (v24 >= 0) a->p144 = a->c92 - (v24 < v25 ? v24 : v25);
  else { int v29 = -v25; a->p144 = a->c92 - (v24 > v29 ? v24 : v29); }
}
static int an_kkfPick(Ana *a, int W) {
  int n = a->kkfN, v6 = n >> 1, a2 = a->c92 - 1, a3 = a->p144, a4 = a->c100;
  int v7 = v6 + a3, v8 = v6 - a2, v9 = v7 + a4, v10 = v7 - a4;
  if (v10 >= v8) { int v11 = v6 + a2; if (v9 > v11) { v9 = v11 - 1; v10 = v11 - 1 - 2 * a4; } }
  else { v10 = v8 - 1; v9 = v8 - 1 + 2 * a4; }
  if (v10 > v9) return v7 - v6;
  const f32 *buf = a->buf.p; int H = a->c92, L = W; f32 best = 0; int bi = -1;
  for (int j = v10; j <= v9; j++) {
    if (j < 0 || j >= n) continue;
    int m = j - v6, i0 = imax(0, -m), i1 = imin(L, L - m); double s = 0;
    for (int i = i0; i < i1; i++) s += (double)buf[i + m] * (double)buf[H + i];
    f32 r = (f32)(s * n); f32 v = (f32)floor((f32)(r * 10000.0f));
    if (v > best) { best = v; bi = j; }
  }
  return bi == -1 ? v7 - v6 : bi - v6;
}
static f32 an_score(f32 v68, f32 v69, double thr, int f272, int f276) {
  if (!(v68 > v69) || !((double)v68 > thr) || f272 || f276) return 0;
  double t = ((double)v68 + 1e-31) / ((double)v69 + 1e-31) * (double)(f32)(v68 - v69);
  t = (t + 1e-31) / ((double)(f32)(v69 + v68) + 1e-31);
  return (f32)tanh(t);
}
static f32 an_transient(Ana *a, int n) {
  const f32 *b = a->buf.p; const f32 c4 = 0.5f, c3 = -0.5f; f32 pk = -3.4028235e38f, z = a->firZ;
  for (int i = 0; i < n; i++) { f32 x = b[i]; f32 v = fabsf((f32)(x * c4) + (f32)(c3 * z)); z = x; if (v > pk) pk = v; }
  if (n) a->firZ = b[n - 1];
  f32 v68 = pk, v70 = an_score(v68, a->pk232, 0.01, a->fl272, a->fl276); a->pk232 = v68;
  f32 y = a->iirY, pk2 = -3.4028235e38f; const f32 C3 = a->iirC3, C4 = a->iirC4, tiny = 1e-24f;
  for (int i = 0; i < n; i++) { y = (f32)((f32)(b[i] * C4) + (f32)(C3 * y)) + tiny; f32 v = fabsf(y); if (v > pk2) pk2 = v; }
  a->iirY = y; f32 v77 = pk2;
  f32 v79 = an_score(v77, a->pk236, 0.1, a->fl272, a->fl276); a->pk236 = v77;
  if (!(v70 > v79)) v70 = v79;
  a->fl276 = a->fl272; a->fl272 = (double)v70 > 0.69999999 ? 1 : 0;
  return v70;
}
static void an_process(Ana *a, const f32 *mono, int n) {
  fv_append(&a->buf, mono, n); fv_append(&a->tbuf, mono, n);
  while (a->buf.n >= 2 * a->c80) {
    a->hop184 = tr_hop(a->T);
    if (a->p124 + imax(a->c80, a->c88) >= a->p176) {
      int done = 0;
      for (;;) {
        int h = a->hop184;
        if (a->tbuf.n <= h + a->c80) break;
        f32 o[5]; tr_feed(a->T, a->tbuf.p, h, o); a->f296 = o[0]; a->f300 = o[1];
        if (a->f296 <= 0) a->f244 = -1;
        else { f32 v14 = a->sr / a->f296; if ((f32)(2 * a->c80) <= v14) v14 = (f32)(2 * a->c80); a->f244 = v14; }
        int v16 = (int)floorf(a->f244 + 0.5f);
        fv_shift(&a->tbuf, h); a->p176 += h;
        a->hop184 = tr_hop(a->T);
        int v7 = a->c80;
        if (v16 <= 0) { a->c88 = v7 >> 2; a->c92 = v7 >> 3; a->c96 = v7 >> 4; if (a->c100 > v7 >> 4) a->c100 = v7 >> 5; }
        else an_setVoiced(a, a->f244);
        if (a->p124 + imax(v7, a->c88) < a->p176) { done = 1; break; }
      }
      if (!done) return;
    }
    int v32 = (int)a->f244;
    if (v32 > 0 && v32 < 2 * a->c156) {
      int v35 = imin(2 * a->c80, 2 * v32); v35 = imax(v35, 2 * a->c156);
      a->c88 = v35; int v38 = v35 >> 1; a->c92 = v38; int v40 = v38 >> 1; a->c96 = v40;
      int v39 = imax((int)((double)a->f244 * 0.0625), a->c156 >> 2); v39 = imin(v39, v40);
      a->p144 = v38 - v32; a->c100 = v39;
    }
    int W = a->c88;
    if (W > a->buf.n) return;
    int p128 = a->p124 + a->c92, v42 = a->c80;
    if (W <= v42 >> 3) a->kkfN = v42 >> 2; else if (W <= v42 >> 2) a->kkfN = v42 >> 1;
    else if (W <= v42 >> 1) a->kkfN = v42; else if (W <= v42) a->kkfN = 2 * v42; else if (W <= 2 * v42) a->kkfN = 4 * v42;
    f32 peak = -3.4028235e38f; for (int i = 0; i < W; i++) { f32 v = fabsf(a->buf.p[i]); if (v > peak) peak = v; }
    int lag = peak >= 1e-24f ? an_kkfPick(a, W) : 0;
    int p140 = lag, v45 = lag; a->p144 = lag;
    if (a->f300 != 0) {
      int v46 = p128 - lag - a->p124;
      if (v46 > 4 * a->c156) {
        int v47 = a->c92, v49 = v46 >> 1, base = v47 - lag; const f32 *b = a->buf.p;
        f32 e0 = b[base], v51 = (f32)(e0 * 1.25f) * e0;
        for (int j = -v49; j < v49; j++) { int k = imax(base + j, 1); f32 e = b[k] * b[k]; if (e > v51) { v51 = e; v45 = j; } }
        if (v45 >= -4) { if (v45 <= 4) { int v60 = imax(v45 + v47 - lag, 1); v45 = v47 - v60; } else v45 = lag - 2; }
        else v45 = lag + 2;
      }
      if (-a->c92 < v45 && v45 < a->c92) p140 = v45;
    }
    p128 -= p140;
    int p188 = p128 - a->p124;
    if (p128 - a->marks[a->nm - 1] >= a->c156 >> 2) {
      if (p188 > a->buf.n) return;
      f32 f8 = an_transient(a, p188); an_push(a, p128, f8);
    }
    fv_shift(&a->buf, p188); a->p124 = p128;
  }
}

/* ================================================================ PSOLA synthesis */
typedef struct {
  int ch, block; f32 pitch, invPitch, invStretch, c72, c80;
  f32 **xin; int xl, xcap; int64_t xbase;            /* xin[c][i] <-> abs input xbase + i */
  f32 **out; int ocap; int64_t obase;                 /* out[c][i] <-> abs output obase + i */
  double rd; int prev, L, rep; int64_t w148, w152, produced; int R164; int64_t received;
  int ri_n; int *ri; int ri2_n; int *ri2;             /* ramp index caches (last two lengths) */
} Syn;
static void sy_init(Syn *s, int ch, int block) {
  memset(s, 0, sizeof *s); s->ch = ch; s->block = block; s->rep = 1;
  s->xin = calloc(ch, sizeof(f32 *)); s->out = calloc(ch, sizeof(f32 *)); s->xcap = 1 << 16; s->ocap = 1 << 16;
  for (int c = 0; c < ch; c++) { s->xin[c] = calloc(s->xcap, sizeof(f32)); s->out[c] = calloc(s->ocap, sizeof(f32)); }
  s->obase = -(1 << 14);
}
static void sy_set(Syn *s, f32 pitch, f32 stretch) {
  s->pitch = pitch; s->invPitch = 1.0f / pitch; s->invStretch = 1.0f / stretch;
  f32 v3 = 1.0f / pitch; s->c72 = v3 <= 1 ? 1 : v3; f32 v2 = 1.0f / stretch; s->c80 = v2 <= 1 ? 1 : v2;
}
static inline f32 sy_src(Syn *s, int c, int64_t i) { int64_t k = i - s->xbase; return (k >= 0 && k < s->xl) ? s->xin[c][k] : 0; }
static void sy_add(Syn *s, f32 *const *chans, int n) {
  if (s->xl + n > s->xcap) { int nc = imax(s->xcap * 2, s->xl + n); for (int c = 0; c < s->ch; c++) s->xin[c] = realloc(s->xin[c], sizeof(f32) * nc); s->xcap = nc; }
  for (int c = 0; c < s->ch; c++) memcpy(s->xin[c] + s->xl, chans[c], sizeof(f32) * n);
  s->xl += n; s->received += n;
}
static void sy_ensure(Syn *s, int64_t endAbs) {
  int64_t need = endAbs - s->obase + 1;
  if (need > s->ocap) { int nc = (int)(need > 2 * (int64_t)s->ocap ? need : 2 * (int64_t)s->ocap);
    for (int c = 0; c < s->ch; c++) { s->out[c] = realloc(s->out[c], sizeof(f32) * nc); memset(s->out[c] + s->ocap, 0, sizeof(f32) * (nc - s->ocap)); } s->ocap = nc; }
}
static const int *rampIdx(Syn *s, int n, int which) {
  int **p = which ? &s->ri2 : &s->ri; int *pn = which ? &s->ri2_n : &s->ri_n;
  if (*pn != n || !*p) {
    *p = realloc(*p, sizeof(int) * (n > 0 ? n : 1)); *pn = n;
    f32 scale = n <= 1 ? (f32)N_RAMP : (f32)(N_RAMP - 1) / (f32)(n - 1);
    for (int i = 0; i < n; i++) (*p)[i] = (int)((double)((f32)i * scale) + 0.5);
  }
  return *p;
}
static void sy_grain(Syn *s, int L, int R, int64_t P) {
  s->R164 = R;
  int a2 = L;
  if (s->pitch < 1) { f32 v7 = (f32)a2 * s->pitch; if ((f32)a2 <= v7) v7 = (f32)a2; a2 = (int)v7; }
  f32 v9 = (f32)R * s->invPitch; if (v9 > (f32)R) v9 = (f32)R; int v10 = (int)v9;
  int zend = (int)floorf((f32)((f32)R * s->invPitch) + 1.5f);
  int64_t sAbs = s->w148 - a2; sy_ensure(s, sAbs + a2 + imax(v10, zend) + 1);
  int64_t s0 = sAbs - s->obase;
  if (a2 > 0) { const int *ri = rampIdx(s, a2, 0);
    for (int c = 0; c < s->ch; c++) { f32 *o = s->out[c] + s0; for (int i = 0; i < a2; i++) o[i] = o[i] + RAMP[ri[i]] * sy_src(s, c, P - a2 + i); } }
  int64_t s1 = s0 + a2;
  if (v10 > 0) { const int *ri = rampIdx(s, v10, 1);
    for (int c = 0; c < s->ch; c++) { f32 *o = s->out[c] + s1; for (int i = 0; i < v10; i++) o[i] = (f32)(1.0f - RAMP[ri[i]]) * sy_src(s, c, P + i); } }
  if (zend > v10) for (int c = 0; c < s->ch; c++) memset(s->out[c] + s1 + v10, 0, sizeof(f32) * (zend - v10));
  s->w152 = sAbs + a2; s->w148 = s->w152 + (int)floorf((f32)R * s->invPitch);
}
static int searchMark(const int *pos, int n, int start, int target) {
  if (start >= n - 1 || n < 2) return -1;
  int best = abs(pos[start] - target), j = start + 1;
  while (j < n) { int d = abs(pos[j] - target); if (d >= best) break; best = d; j++; }
  if (j == n) return n - 1;
  return j - 1 > 0 ? j - 1 : 0;
}
/* returns 1 and fills s->out[..][block] window at `produced`, or 0 (synth returned -1) */
static int sy_call(Syn *s, const int *pos, int n) {
  int64_t blockEnd = s->produced + s->block;
  while (s->w152 < blockEnd) {
    int idx = searchMark(pos, n, s->prev, (int)s->rd);
    if (idx < 0 && s->rep == 1) idx = s->prev;
    if (idx < 0) return 0;
    int R = (idx >= 0 && idx < n - 1) ? pos[idx + 1] - pos[idx] : -1;
    if (R < 0) R = (int)((f32)((f32)s->L * s->pitch) + 0.5f);
    sy_grain(s, s->L, R, pos[idx]);
    s->rep = idx == s->prev ? s->rep + 1 : 1; s->prev = idx;
    f32 Rout = (f32)R * s->invPitch;
    s->L = imax(0, (int)floorf(Rout + 0.5f));
    s->rd = s->rd + floorf(Rout * s->invStretch);
  }
  return 1;
}
static int sy_needed(Syn *s, const int *pos, const f32 *f8, int n, int block2) {
  int64_t v1 = s->w152 - s->produced, v29 = v1; double v3 = s->rd; int v4 = s->prev, v5 = s->rep;
  f32 v12 = (f32)(s->w148 - s->w152); int64_t v11 = 0;
  if (n == 0) return -1;
  if (v1 >= block2) return 0;
  for (;;) {
    int v14 = searchMark(pos, n, v4, (int)v3);
    f32 f8v = (v14 >= 0 && v14 < n) ? f8[v14] : -1;
    if (f8v > 0.7 && v14 == v4) v14 = v4 + 1;
    if (v14 < 0) return v14;
    int v15 = (v14 >= 0 && v14 < n - 1) ? pos[v14 + 1] - pos[v14] : -1;
    if (v15 < 0) return -1;
    int64_t v23 = (int64_t)(int)((f32)((f32)v15 * s->c72) * s->c80) - s->received + pos[v14];
    if (v11 < v23) v11 = v23;
    v5 = v14 == v4 ? v5 + 1 : 1; v4 = v14;
    int64_t v24 = (int64_t)(int)v12 + v29; v29 = v24;
    int v25 = (int)floorf((f32)((f32)v15 * s->invPitch) + 0.5f); if (v25 < 2) v25 = 2;
    v12 = (f32)v25;
    v3 = v3 + floorf((f32)((f32)s->R164 * s->invPitch) * s->invStretch);
    if (v24 >= block2) return v11 > 0 ? (int)v11 : 0;
  }
}

/* ================================================================ engine */
struct E3 {
  int sr, ch, block; Track T; Ana A; Syn S; f32 stretch, pitch;
  f32 **inb; f32 *mono; int incap; f32 **outb;
};
E3 *e3_new(int sr, int ch, int block) {
  if (sr < 32000 || sr >= 64000 || ch < 1 || ch > 8 || block < 1 || block > 1024) return 0;
  E3 *e = calloc(1, sizeof *e); e->sr = sr; e->ch = ch; e->block = block;
  tr_init(&e->T, sr); an_init(&e->A, &e->T, (f32)sr); sy_init(&e->S, ch, block);
  e->stretch = 1; e->pitch = 1; sy_set(&e->S, 1, 1);
  e->inb = calloc(ch, sizeof(f32 *)); e->outb = calloc(ch, sizeof(f32 *));
  for (int c = 0; c < ch; c++) e->outb[c] = calloc(block, sizeof(f32));
  return e;
}
void e3_set(E3 *e, float pitch, float stretch) { e->pitch = pitch; e->stretch = stretch; sy_set(&e->S, pitch, stretch); }
int e3_needed(E3 *e) {
  int v3 = sy_needed(&e->S, e->A.marks, e->A.f8, e->A.nm, 2 * e->block);
  if (v3 < -1) v3 = -1;
  if (v3 < 0) {
    int c44 = 2048, c40 = imax(2 * e->block, imax(c44 + (c44 >> 1), 2 * c44 + (c44 >> 1)));
    f32 v4 = 1; if (e->stretch <= 1) v4 = e->stretch;
    f32 v5 = (f32)((f32)c44 / v4) + (f32)(e->block + c44); if (v5 <= (f32)c40) v5 = (f32)c40;
    v3 = (int)v5;
  }
  return v3;
}
float *e3_inbuf(E3 *e, int c, int n) {
  if (n > e->incap) { for (int k = 0; k < e->ch; k++) e->inb[k] = realloc(e->inb[k], sizeof(f32) * n); e->mono = realloc(e->mono, sizeof(f32) * n); e->incap = n; }
  return e->inb[c];
}
float *e3_outbuf(E3 *e, int c) { return e->outb[c]; }
static void trim(E3 *e) {
  Ana *A = &e->A; Syn *S = &e->S;
  if (A->nm > 1024) {                                  /* DLL: keep last count-128, shift synth indices */
    memmove(A->marks, A->marks + 128, sizeof(int) * (A->nm - 128)); memmove(A->f8, A->f8 + 128, sizeof(f32) * (A->nm - 128));
    A->nm -= 128; S->prev -= 128;
  }
  /* drop synth input older than the oldest reachable grain start: mark[prev] minus a full window */
  int64_t keep = (int64_t)A->marks[S->prev > 0 ? S->prev : 0] - (1 << 16);
  if (keep - S->xbase > (1 << 17)) { int k = (int)(keep - S->xbase); for (int c = 0; c < S->ch; c++) memmove(S->xin[c], S->xin[c] + k, sizeof(f32) * (S->xl - k)); S->xl -= k; S->xbase += k; }
  /* drop consumed output */
  int64_t drop = S->produced - S->obase - (1 << 14);
  if (drop > (1 << 16)) { for (int c = 0; c < S->ch; c++) { memmove(S->out[c], S->out[c] + drop, sizeof(f32) * (S->ocap - drop)); memset(S->out[c] + S->ocap - drop, 0, sizeof(f32) * drop); } S->obase += drop; }
}
int e3_process(E3 *e, int n) {
  for (int i = 0; i < n; i++) e->mono[i] = 0;
  for (int c = 0; c < e->ch; c++) for (int i = 0; i < n; i++) e->mono[i] = e->mono[i] + e->inb[c][i];
  an_process(&e->A, e->mono, n);
  sy_add(&e->S, e->inb, n);
  int ok = sy_call(&e->S, e->A.marks, e->A.nm);
  if (ok) { int64_t o0 = e->S.produced - e->S.obase; for (int c = 0; c < e->ch; c++) memcpy(e->outb[c], e->S.out[c] + o0, sizeof(f32) * e->block); e->S.produced += e->block; }
  trim(e);
  return ok;
}
void e3_free(E3 *e) { (void)e; /* process-lifetime engines; freeing omitted for brevity in wasm (instance is dropped) */ }
