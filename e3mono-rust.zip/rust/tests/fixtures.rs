// bit-exactness vs FL Studio 20's elastique_x64.dll (fixtures recorded in web/fixture*.json)
use serde_json::Value;
fn run(file: &str, sr: i32) {
    let fx: Value = serde_json::from_str(&std::fs::read_to_string(file).unwrap()).unwrap();
    for (name, c) in fx.as_object().unwrap() {
        let x: Vec<Vec<f32>> = c["x"].as_array().unwrap().iter().map(|ch| ch.as_array().unwrap().iter().map(|v| v.as_f64().unwrap() as f32).collect()).collect();
        let want: Vec<Vec<f32>> = c["y"].as_array().unwrap().iter().map(|ch| ch.as_array().unwrap().iter().map(|v| v.as_f64().unwrap() as f32).collect()).collect();
        let sched: Vec<(f32, f32)> = c["sched"].as_array().unwrap().iter().map(|r| (r[0].as_f64().unwrap() as f32, r[1].as_f64().unwrap() as f32)).collect();
        let (mut kp, mut ks) = (0, 0);
        let t0 = std::time::Instant::now();
        let y = e3mono::render(&x, sr, |_| { let v = sched[kp].1; kp += 1; v }, |_| { let v = sched[ks].0; ks += 1; v }, 512);
        let dt = t0.elapsed();
        let n = y[0].len().min(want[0].len()); let mut md = 0f32;
        for ch in 0..y.len() { for i in 0..n { md = md.max((y[ch][i] - want[ch][i]).abs()); } }
        println!("{sr} {name}: len {} vs dll {}  max|diff| {md:e}  {:?}", y[0].len(), want[0].len(), dt);
        assert_eq!(y[0].len(), want[0].len(), "{name} length"); assert_eq!(md, 0.0, "{name} not bit-exact");
    }
}
#[test] fn dll_44k() { run("fixtures/fixture.json", 44100); }
#[test] fn dll_48k() { run("fixtures/fixture48.json", 48000); }
