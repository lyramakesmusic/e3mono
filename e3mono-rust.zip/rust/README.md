# e3mono (Rust)

FL Studio's "elastique 3 mono" (zplane elastique Pro V3, SOLO/PSOLA mode), rebuilt from the FL Studio 20 binary.
Output matches FL's `elastique_x64.dll` sample for sample (`cargo test --release` checks this against recorded DLL renders).

```rust
let out = e3mono::render(&[left, right], 44100, |_t| 0.5 /* pitch */, |_t| 1.0 /* stretch */, 512);
```

Streaming: `E3::new(sr, ch, 512)`, then per step `set(pitch, stretch)`, `needed()`, fill `input(c, n)`, `process(n)` → `output(c)`.
44.1 / 48 kHz.
