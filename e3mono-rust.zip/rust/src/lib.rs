//! elastique Pro V3 "mono" (FL Studio's E3 mono, zplane `CelastiqueSOLOV3`) in Rust.
//! Port of `c/e3.c`, which is bit-exact against FL Studio 20's `elastique_x64.dll`.
//!
//! Streaming API:
//! ```ignore
//! let mut e = e3mono::E3::new(44100, 2, 512).unwrap();
//! loop {
//!     e.set(pitch, stretch);
//!     let n = e.needed();
//!     // write n frames per channel into e.input(c, n)
//!     if e.process(n) { /* e.output(c) holds one block */ }
//! }
//! ```
//! All float math mirrors the binary: f32 where the DLL uses SSE single precision, f64 where it uses
//! double. No `mul_add` anywhere (FMA would change results).

mod tables;
use tables::*;

const N_RAMP: usize = 0x4000;

// ================================================================ f64 FFT (complex radix-2, real via N/2 trick)
struct Fft { n: usize, cs: Vec<f64>, sn: Vec<f64>, rev: Vec<usize>, re: Vec<f64>, im: Vec<f64> }
impl Fft {
    fn new(n: usize) -> Self {
        let bits = n.trailing_zeros();
        let rev = (0..n).map(|i| { let mut r = 0; let mut x = i; for _ in 0..bits { r = (r << 1) | (x & 1); x >>= 1; } r }).collect();
        let cs = (0..n / 2).map(|i| (2.0 * std::f64::consts::PI * i as f64 / n as f64).cos()).collect();
        let sn = (0..n / 2).map(|i| (2.0 * std::f64::consts::PI * i as f64 / n as f64).sin()).collect();
        Fft { n, cs, sn, rev, re: vec![0.0; n], im: vec![0.0; n] }
    }
    fn run(&mut self, inverse: bool) {
        let n = self.n; let (re, im) = (&mut self.re, &mut self.im);
        for i in 0..n { let j = self.rev[i]; if j > i { re.swap(i, j); im.swap(i, j); } }
        let mut size = 2;
        while size <= n {
            let half = size >> 1; let step = n / size;
            let mut s = 0;
            while s < n {
                for k in 0..half {
                    let wr = self.cs[k * step]; let wi = if inverse { self.sn[k * step] } else { -self.sn[k * step] };
                    let a = s + k; let b = a + half;
                    let tr = re[b] * wr - im[b] * wi; let ti = re[b] * wi + im[b] * wr;
                    re[b] = re[a] - tr; im[b] = im[a] - ti; re[a] += tr; im[a] += ti;
                }
                s += size;
            }
            size <<= 1;
        }
    }
}
struct RFft { n: usize, c: Fft, tc: Vec<f64>, ts: Vec<f64> }
impl RFft {
    fn new(n: usize) -> Self {
        let tc = (0..n / 2).map(|k| (2.0 * std::f64::consts::PI * k as f64 / n as f64).cos()).collect();
        let ts = (0..n / 2).map(|k| (2.0 * std::f64::consts::PI * k as f64 / n as f64).sin()).collect();
        RFft { n, c: Fft::new(n / 2), tc, ts }
    }
    /// forward, IPP perm format [R0, R_{N/2}, R1, I1, ...], unscaled, as f32
    fn perm(&mut self, x: &[f32], o: &mut [f32]) {
        let m = self.n / 2;
        for i in 0..m { self.c.re[i] = x[2 * i] as f64; self.c.im[i] = x[2 * i + 1] as f64; }
        self.c.run(false);
        let (re, im) = (&self.c.re, &self.c.im);
        o[0] = (re[0] + im[0]) as f32; o[1] = (re[0] - im[0]) as f32;
        for k in 1..m {
            let (zr, zi, wr2, wi2) = (re[k], im[k], re[m - k], -im[m - k]);
            let (er, ei, dr, di) = (0.5 * (zr + wr2), 0.5 * (zi + wi2), 0.5 * (zr - wr2), 0.5 * (zi - wi2));
            let (c, s, tr, ti) = (self.tc[k], self.ts[k], di, -dr);
            o[2 * k] = (er + (tr * c + ti * s)) as f32; o[2 * k + 1] = (ei + (ti * c - tr * s)) as f32;
        }
    }
    /// unscaled inverse (= N * idft) from perm input
    fn iperm(&mut self, p: &[f32], o: &mut [f32]) {
        let m = self.n / 2;
        for k in 0..m {
            let (xr, xi, yr, yi) = if k == 0 { (p[0] as f64, 0.0, p[1] as f64, 0.0) }
                else { (p[2 * k] as f64, p[2 * k + 1] as f64, p[2 * (m - k)] as f64, -(p[2 * (m - k) + 1] as f64)) };
            let (er, ei, dr, di) = (xr + yr, xi + yi, xr - yr, xi - yi);
            let (c, s) = (self.tc[k], self.ts[k]);
            let (tr, ti) = (dr * c - di * s, dr * s + di * c);
            self.c.re[k] = er - ti; self.c.im[k] = ei + tr;
        }
        self.c.run(true);
        for i in 0..m { o[2 * i] = self.c.re[i] as f32; o[2 * i + 1] = self.c.im[i] as f32; }
    }
}

// ================================================================ tracker (CPitchTrack)
const SR_T: i32 = 11025;
const NFFT: usize = 8192;
const HOP: i32 = 128;
const FRAME: usize = 1024;

struct Resampler { nwing: i32, half: i32, xoff: i32, xp: i32, xread: i32, ptr: i32, nx: i32, first: bool, time: f64, buf: Vec<f32> }
impl Resampler {
    fn new() -> Self {
        let nwing = 768; let v6 = ((nwing / 128) + 2) >> 1; let hist = 1000 * v6 + 1; let size = hist + (2 * v6 + 0x4000);
        Resampler { nwing, half: v6, xoff: 2 * v6, xp: 2 * v6, xread: 2 * v6, ptr: hist, nx: 0, first: true, time: (2 * v6) as f64,
                    buf: vec![0.0; (size + hist) as usize] }
    }
    fn hop(&self, sr: i32, nout: i32) -> i32 {
        let v4 = sr as f32 / SR_T as f32; let prod = nout as f32 * v4;
        if self.first {
            let v5 = if v4 >= 1.0 { v4 as f64 } else { 1.0 }; let t = self.half as f64 * v5 + 1.0;
            let v8 = if self.xoff as f64 > t { self.xoff as f64 } else { t };
            let v11 = (prod as f64 + v8).ceil(); return if v11 >= 0.0 { v11 as i32 } else { 0 };
        }
        let v16 = ((prod - self.nx as f32) as f64).ceil(); if v16 >= 0.0 { v16 as i32 } else { 0 }
    }
    fn filt(&mut self, factor: f32, nx: i32, gain: f32, out: &mut Vec<f32>) {
        let v11 = 1.0f32 / factor; let inc = v11 as f64;
        let mut v7 = factor * 256.0; if v7 > 256.0 { v7 = 256.0; }
        let dhb = ((v7 * 128.0) as f64 + 0.5) as i64; let lim = 100 * nx; let mut k = 0i32;
        let nw = (self.nwing << 7) as i64; let nr = nw - 128; let base = self.ptr as i64; let c = 0.0078125f32;
        while (((((k as f32) * v11) * 100.0) + 0.5).floor() as i32) < lim {
            let tm = self.time; self.time += inc; k += 1;
            let t = (tm * 32768.0) as i64; let idx = t >> 15; let frac = t & 0x7FFF;
            let (mut left, mut right) = (0f32, 0f32);
            let mut ph = (dhb * frac) >> 15; let mut j = 0i64;
            while ph < nw { let ti = (ph >> 7) as usize; let co = (((ph & 0x7F) as f32 * c) * IMPD[ti]) + IMP[ti];
                left += co * self.buf[(base + idx - j) as usize]; ph += dhb; j += 1; }
            let rf = (-t) & 0x7FFF; ph = (rf * dhb) >> 15; if rf == 0 { ph += dhb; } j = 0;
            while ph < nr { let ti = (ph >> 7) as usize; let co = (((ph & 0x7F) as f32 * c) * IMPD[ti]) + IMP[ti];
                right += co * self.buf[(base + idx + 1 + j) as usize]; ph += dhb; j += 1; }
            out.push((right + left) * gain);
        }
    }
    fn process(&mut self, x: &[f32], sr: i32, out: &mut Vec<f32>) {
        let n = x.len() as i32; let factor = SR_T as f32 / sr as f32; let v13 = 1.0f32 / factor;
        let v14 = if v13 >= 1.0 { v13 } else { 1.0 }; let v15 = self.half as f32; let mut v16 = self.xoff as f32;
        if v16 <= (v15 * v14) + 1.0 { v16 = (v15 * (if v13 >= 1.0 { v13 } else { 1.0 })) + 1.0; }
        let nxx = v16 as i32;
        if nxx != self.xoff { let d = nxx - self.xoff; self.xp += d; self.xread += d; self.ptr -= d; self.time += d as f64; }
        self.xoff = nxx;
        let gain = if factor < 1.0 { factor * 0.99000001 } else { 0.99000001 };
        let o = (self.ptr + self.xp + self.nx) as usize; self.buf[o..o + x.len()].copy_from_slice(x);
        self.nx += n; let v18 = self.nx; let mut nx = v18;
        if self.first { self.first = false; nx = v18 - self.xoff; }
        self.nx = self.xp + v18;
        self.filt(factor, nx, gain, out);
        let xo = self.xoff;
        self.xread += nx; self.time -= nx as f64; self.nx -= 2 * xo + nx;
        let v28 = (self.time - xo as f64) as i32;
        if v28 != 0 { self.xread += v28; self.time -= v28 as f64; }
        let lo = -xo; let hi = 3 * xo + self.nx - self.xread + nx; let sh = self.xread - xo;
        if hi > lo { let a = (self.ptr + lo) as usize; let b = (self.ptr + hi) as usize; self.buf.copy_within(a + sh as usize..b + sh as usize, a); }
        self.xp = nx + 3 * xo - self.xread; self.xread = xo;
    }
}

struct TAnalysis {
    rf: RFft, b88: Vec<f32>, spec: Vec<f32>, mag0: Vec<f32>, b112: Vec<f32>, p: Vec<f32>, m: Vec<f32>, b104: Vec<f32>,
    acf: Vec<f32>, mag: Vec<f32>, comb: Vec<f32>, hps: Vec<f32>, dst: Vec<f32>,
    i8: i32, i16: i32, hi_lag: i32, lo_lag: i32, flag172: bool, s36: f32, rms: f32, rms_prev: f32, drms: f32, thr168: f32, h: [f32; 12],
}
fn magperm(p: &[f32], n2: usize, m: &mut [f32]) {
    for k in 0..n2 {
        let (re, im) = if k == 0 { (p[0], 0.0f32) } else { (p[2 * k], p[2 * k + 1]) };
        let s = re * re + im * im;
        m[k] = if s > 0.0 && s < 1.1754944e-38 { f32::INFINITY } else { s.sqrt() };
    }
}
fn argmax0(a: &[f32], lo: usize, hi: usize) -> i32 { let mut m = 0f32; let mut bi = 0; for i in lo..hi { if a[i] > m { m = a[i]; bi = i - lo; } } bi as i32 }
fn max_from(a: &[f32], lo: usize, hi: usize, fl: f32) -> f32 { let mut m = f32::NEG_INFINITY; for i in lo + 1..hi { if a[i] > m { m = a[i]; } } if m > fl { m } else { fl } }
fn refine(a0: f64, a1: f64, a2: f64) -> f32 {
    let v4 = (a1 - a0) / 30.0; let c = ((a2 - a0) - 60.0 * v4) / (60.0 * 30.0);
    let mut prev = -1.0000000195414814e-25; let mut x = 0.0f64;
    loop { let cur = (x * c) * (x - 30.0) + (x * v4 + a0); if prev >= cur { return ((x - 1.0) / 30.0) as f32; } prev = cur; x += 1.0; if !(60.0 >= x) { return 0.0; } }
}
impl TAnalysis {
    fn new() -> Self {
        let n = NFFT;
        TAnalysis { rf: RFft::new(n), b88: vec![0.0; n], spec: vec![0.0; n], mag0: vec![0.0; n / 2], b112: vec![0.0; n], p: vec![0.0; n],
            m: vec![0.0; n / 2], b104: vec![0.0; n], acf: vec![0.0; n], mag: vec![0.0; n], comb: vec![0.0; n], hps: vec![0.0; n / 2], dst: vec![0.0; n],
            i8: 0, i16: 0, hi_lag: ((44 * n) as f32 * 0.00012207031f32) as i32, lo_lag: ((28 * n) as f32 * 0.00012207031f32) as i32,
            flag172: false, s36: 0.0, rms: 0.0, rms_prev: 0.0, drms: 0.0, thr168: 0.0, h: [0.0; 12] }
    }
    fn decide(&mut self, out: &mut [f32; 5]) {
        let n = NFFT as i32; let n2 = n >> 1; let h = &mut self.h;
        let mut v2 = self.i8; let v6 = h[11]; let v8 = h[0];
        if v6 > 0.0 && v8 > 0.0 {
            let fq = (11025 * v2) as f32 / n as f32;
            if (fq as f64) > ((v8 + v6) as f64) * 1.8 * 0.5 || self.flag172 {
                let v9 = self.i16; self.flag172 = false;
                if v9 > self.hi_lag && v2 as f64 * 0.3 >= (v2 as f64 - v9 as f64 * 2.0).abs() { v2 = v9; self.flag172 = true; }
            } else { self.flag172 = false; }
        }
        let hps = &self.hps; let mag = &self.mag;
        let v13 = (11025 * v2) as f32; let v14 = v13 / n as f32; let thr = hps[v2 as usize] as f64 * 0.25;
        let mut v11 = v2; while v11 > 0 && !(thr > hps[v11 as usize] as f64) { v11 -= 1; }
        let mut v20 = v2; while v20 < n2 && !(thr > hps[v20 as usize] as f64) { v20 += 1; }
        let v29 = ((n * 25) as f32 / 11025.0) as i32; let v25 = (v2 >> 3).max(v29);
        let mut s36 = (v20 - v11) as f32 / v25 as f32;
        let v26 = ((n * -25) as f32 / 11025.0) as i32; let v31 = (v2 - v29).max(1); let v33 = (v2 - v26).min(n2);
        let v36 = hps[v2 as usize] as f64; let mut v37 = 1.0 / v36; for i in v31..v33 { v37 *= hps[i as usize] as f64; }
        let g = v36 / v37.powf(1.0 / (v33 - v31) as f64);
        let mut v41 = g as f32 as f64; if v41 > 2.0 { v41 = 2.0; }
        s36 = (2.0 - v41) as f32 + s36; self.s36 = s36;
        let uv_forced = (s36 > 1.0 && ((v6 as f64) * 0.75 > v14 as f64 || (v14 as f64) * 0.75 > v6 as f64) && v6 > 0.0) || v2 <= 0;
        let s32 = if !uv_forced {
            let mut v7 = 0f32; for i in v2..n2 { v7 += mag[i as usize]; }
            let v48 = v7 / (n2 - v2) as f32; let mut s32 = 0f32; let mut v47 = v2;
            if v2 < (n >> 2) { let mut acc = 0f32; while v47 < (n >> 2) { acc += mag[v47 as usize]; v47 += v2; } s32 = acc; }
            if 1e-7f32 >= self.rms * self.rms { 1.0 } else if v47 == v2 { s32 / v48 } else { s32 / ((v47 / v2 - 1) as f32 * v48) }
        } else { 1.0 };
        let db = ((s32 as f64).ln() as f32) * 4.3429446f32; out[1] = db;
        let v54 = n as f32; let v55 = v13 / v54;
        let goto_b = if !(3.5f32 > db) { true } else if 160.0 > v55 { false } else { true };
        let mut voiced = false; if goto_b { if !(self.thr168 > db) { voiced = true; } else if !(v55 >= 160.0) { voiced = true; } }
        let u = v2 as usize;
        if voiced {
            let r = refine(mag[u - 1] as f64, mag[u] as f64, mag[u + 1] as f64);
            let f = (((r + v2 as f32) - 1.0) * 11025.0) / v54;
            for i in (1..=9).rev() { h[i] = h[i - 1]; }
            h[0] = h[10]; h[10] = out[0]; h[11] = out[0]; out[0] = f;
        } else {
            let v56 = out[0];
            if ((v56 - v55).abs() as f64) > v56 as f64 * 0.2 { v2 = (((v54 * h[5]) / 11025.0) + 0.5) as i32; }
            let mut v3 = 0f32;
            if v2 > 0 { let u = v2 as usize; v3 = (refine(mag[u - 1] as f64, mag[u] as f64, mag[u + 1] as f64) + v2 as f32) - 1.0; }
            h[11] = v56; out[0] = (v3 * 11025.0) / v54; out[1] = 0.0;
        }
        out[4] = self.s36; out[2] = self.rms; out[3] = self.drms;
    }
    fn analyze(&mut self, frame: &[f32], out: &mut [f32; 5]) {
        let n = NFFT; let n2 = n >> 1;
        let mut s = 0f64; for &v in frame { s += if v as f64 > 1e-24 { (v * v) as f64 } else { 1e-24 }; }
        let v7 = ((s as f32) / FRAME as f32).sqrt(); self.rms = v7;
        self.drms = (v7 - self.rms_prev) / (v7 + 1e-32f32); self.rms_prev = v7;
        self.b88.iter_mut().for_each(|v| *v = 0.0); for i in 0..FRAME { self.b88[i] = frame[i] * WIN[i]; }
        self.rf.perm(&self.b88, &mut self.spec); magperm(&self.spec, n2, &mut self.mag0);
        let lo = 6usize.max(((((2 * n2) as f32) * 25.0) / 11025.0) as usize); let hi = ((((2 * n2) as f32) * 200.0) / 11025.0) as usize;
        let tf = f32::from_bits(TINYFILL_BITS);
        self.b112.iter_mut().for_each(|v| *v = 0.0); for i in 0..lo { self.b112[i] = tf; }
        for k in lo..hi { if self.mag0[k] > self.mag0[k - 1] && self.mag0[k] >= self.mag0[k + 1] { for i in k - 4..k + 5 { self.b112[i] = self.mag0[i]; } } }
        for i in hi - 4..n2 { self.b112[i] = self.mag0[i]; }
        self.rf.perm(&self.b112, &mut self.p); magperm(&self.p, n2, &mut self.m);
        self.b104.iter_mut().for_each(|v| *v = 0.0); self.b104[0] = self.m[0] * self.m[0];
        for k in 1..n2 { self.b104[2 * k] = self.m[k] * self.m[k]; }
        self.rf.iperm(&self.b104, &mut self.acf);
        let inv88 = 1.0f32 / max_from(&self.mag0, 0, n2, 1e-25);
        for k in 0..n2 { self.mag[k] = self.mag0[k] * inv88; } for k in n2..n { self.mag[k] = self.spec[k]; }
        let inv112 = 1.0f32 / max_from(&self.acf, 0, n2, 1e-25);
        self.comb.iter_mut().for_each(|v| *v = 0.0);
        for k in 0..n2 { self.comb[k] = (self.mag[k] * 0.25) + (inv112 * self.acf[k]); }
        let mut v16 = 0usize; for k in 1..n >> 3 { if self.comb[k + 1] > self.comb[k] && self.comb[k - 1] > self.comb[k] { v16 = k; break; } }
        let mut v27 = (((n as f32) * 25.0) / 11025.0) as usize; if v16 > v27 { v27 = v16; }
        for i in 0..v27 { self.comb[i] = 0.0; }
        self.b104[..n2].copy_from_slice(&self.comb[..n2]);
        for i in 0..n2 { self.hps[i] = 2.0 * self.b104[i]; }
        for hh in 2..=3usize {
            let q = n2 / hh; let c015 = 0.15000001f32; let hf = hh as f32;
            for i in 0..q { self.hps[i] = ((self.b104[i * hh] + c015) / hf) * self.hps[i]; }
            let cq = c015 / hf; for i in q..n2 { self.hps[i] = cq * self.hps[i]; }
        }
        self.i8 = argmax0(&self.hps, 0, n2);
        self.dst.iter_mut().for_each(|v| *v = 0.0); let kmax = (4000 * n) / 11025;
        for k in self.lo_lag as usize..kmax {
            let nj = 9usize.min((n - 1) / k); let mut sm = 0f32;
            for j in 1..=nj { sm += (self.comb[j * k] * 31.0) / (30 + j) as f32; }
            let kf = k as f32;
            sm -= self.comb[(kf * 0.5) as usize] * 0.25;
            sm -= self.comb[(kf * 0.66659999) as usize] * 0.1;
            sm -= self.comb[(kf * 0.33329999) as usize] * 0.1;
            self.dst[k] = sm / nj as f32;
        }
        self.i16 = argmax0(&self.dst, 0, n2);
        self.decide(out);
    }
}

struct Track { sr: i32, rs: Resampler, lx1: f32, lx2: f32, ly1: f32, ly2: f32, an: TAnalysis, ring: Vec<f32>, wr: usize, rd: usize, out: [f32; 5], frame: Vec<f32>, tmp: Vec<f32> }
impl Track {
    fn new(sr: i32) -> Self {
        Track { sr, rs: Resampler::new(), lx1: 0.0, lx2: 0.0, ly1: 0.0, ly2: 0.0, an: TAnalysis::new(), ring: vec![0.0; 0x4000], wr: 0,
                rd: ((HOP + 0x4000 - FRAME as i32) & 0x3FFF) as usize, out: [0.0; 5], frame: vec![0.0; FRAME], tmp: Vec::with_capacity(0x8000) }
    }
    fn hop(&self) -> i32 { self.rs.hop(self.sr, HOP) }
    fn feed(&mut self, x: &[f32]) -> [f32; 5] {
        self.tmp.clear(); let mut tmp = std::mem::take(&mut self.tmp); self.rs.process(x, self.sr, &mut tmp);
        let (b0, b1, b2, a1, a2, tiny) = (LPF[0], LPF[1], LPF[2], LPF[3], LPF[4], 1e-24f32);
        for &xi in &tmp {
            let y = (((self.lx1 * b1) + (xi * b0)) + (self.lx2 * b2)) + (((self.ly2 * a2) + (self.ly1 * a1)) + tiny);
            self.lx2 = self.lx1; self.lx1 = xi; self.ly2 = self.ly1; self.ly1 = y;
            self.ring[self.wr] = y; self.wr = (self.wr + 1) & 0x3FFF;
        }
        self.tmp = tmp;
        let mut res = [0f32; 5];
        while (self.wr.wrapping_sub(self.rd)) & 0x3FFF >= FRAME {
            for i in 0..FRAME { self.frame[i] = self.ring[(self.rd + i) & 0x3FFF]; }
            let fr = std::mem::take(&mut self.frame); self.an.analyze(&fr, &mut self.out); self.frame = fr;
            res = self.out; self.rd = (self.rd + HOP as usize) & 0x3FFF;
        }
        res
    }
}

// ================================================================ PSOLA analysis (marks)
struct Ana {
    sr: f32, c80: i32, c156: i32, c88: i32, c92: i32, c96: i32, c100: i32, kkf_n: i32, hop184: i32,
    buf: Vec<f32>, tbuf: Vec<f32>, p124: i32, p144: i32, p176: i32, f244: f32, f296: f32, f300: f32,
    marks: Vec<i32>, f8: Vec<f32>, fir_z: f32, iir_y: f32, iir_c3: f32, iir_c4: f32, pk232: f32, pk236: f32, fl272: bool, fl276: bool,
}
fn score(v68: f32, v69: f32, thr: f64, f272: bool, f276: bool) -> f32 {
    if !(v68 > v69) || !((v68 as f64) > thr) || f272 || f276 { return 0.0; }
    let mut t = ((v68 as f64) + 1e-31) / ((v69 as f64) + 1e-31) * ((v68 - v69) as f64);
    t = (t + 1e-31) / (((v69 + v68) as f64) + 1e-31);
    t.tanh() as f32
}
impl Ana {
    fn new(sr: f32) -> Self {
        let c3 = 0.89999998f32;
        Ana { sr, c80: 2048, c156: 32, c88: 2048, c92: 1024, c96: 512, c100: 512, kkf_n: 0, hop184: 0, buf: Vec::new(), tbuf: Vec::new(),
              p124: 0, p144: 0, p176: 0, f244: 2.0, f296: 0.0, f300: 0.0, marks: vec![0], f8: vec![0.0], fir_z: 0.0, iir_y: 0.0,
              iir_c3: c3, iir_c4: 1.0 - c3, pk232: 0.0, pk236: 0.0, fl272: false, fl276: false }
    }
    fn set_voiced(&mut self, p: f32) {
        let (v7, v21, v24) = (self.c80, self.c156, p as i32);
        let mut v23 = if 2 * v24 < 2 * v7 { 2 * v24 } else { 2 * v7 }; if 2 * v21 > v23 { v23 = 2 * v21; }
        self.c88 = v23; let v25 = v23 >> 1; self.c92 = v25; self.c96 = v25 >> 1;
        let v26 = p as f64 * if self.f300 == 0.0 { 0.125 } else { 0.0625 };
        self.c100 = ((v26 as i32).max(v21 >> 2)).min(v25 >> 1);
        self.p144 = if v24 >= 0 { self.c92 - if v24 < v25 { v24 } else { v25 } } else { let v29 = -v25; self.c92 - if v24 > v29 { v24 } else { v29 } };
    }
    fn kkf_pick(&self, w: i32) -> i32 {
        let (n, v6, a2, a3, a4) = (self.kkf_n, self.kkf_n >> 1, self.c92 - 1, self.p144, self.c100);
        let v7 = v6 + a3; let v8 = v6 - a2; let mut v9 = v7 + a4; let mut v10 = v7 - a4;
        if v10 >= v8 { let v11 = v6 + a2; if v9 > v11 { v9 = v11 - 1; v10 = v11 - 1 - 2 * a4; } } else { v10 = v8 - 1; v9 = v8 - 1 + 2 * a4; }
        if v10 > v9 { return v7 - v6; }
        let (buf, h, l) = (&self.buf, self.c92 as usize, w);
        let mut best = 0f32; let mut bi = -1;
        for j in v10..=v9 {
            if j < 0 || j >= n { continue; }
            let m = j - v6; let i0 = 0.max(-m); let i1 = l.min(l - m); let mut s = 0f64;
            for i in i0..i1 { s += buf[(i + m) as usize] as f64 * buf[h + i as usize] as f64; }
            let r = (s * n as f64) as f32; let v = (r * 10000.0).floor();
            if v > best { best = v; bi = j; }
        }
        if bi == -1 { v7 - v6 } else { bi - v6 }
    }
    fn transient(&mut self, n: usize) -> f32 {
        let b = &self.buf; let (c4, c3) = (0.5f32, -0.5f32); let mut pk = -3.4028235e38f32; let mut z = self.fir_z;
        for &x in &b[..n] { let v = ((x * c4) + (c3 * z)).abs(); z = x; if v > pk { pk = v; } }
        if n > 0 { self.fir_z = b[n - 1]; }
        let v68 = pk; let mut v70 = score(v68, self.pk232, 0.01, self.fl272, self.fl276); self.pk232 = v68;
        let mut y = self.iir_y; let mut pk2 = -3.4028235e38f32;
        for &x in &b[..n] { y = ((x * self.iir_c4) + (self.iir_c3 * y)) + 1e-24f32; let v = y.abs(); if v > pk2 { pk2 = v; } }
        self.iir_y = y; let v77 = pk2;
        let v79 = score(v77, self.pk236, 0.1, self.fl272, self.fl276); self.pk236 = v77;
        if !(v70 > v79) { v70 = v79; }
        self.fl276 = self.fl272; self.fl272 = (v70 as f64) > 0.69999999;
        v70
    }
    fn process(&mut self, t: &mut Track, mono: &[f32]) {
        self.buf.extend_from_slice(mono); self.tbuf.extend_from_slice(mono);
        while self.buf.len() as i32 >= 2 * self.c80 {
            self.hop184 = t.hop();
            if self.p124 + self.c80.max(self.c88) >= self.p176 {
                let mut done = false;
                loop {
                    let h = self.hop184;
                    if self.tbuf.len() as i32 <= h + self.c80 { break; }
                    let o = t.feed(&self.tbuf[..h as usize]); self.f296 = o[0]; self.f300 = o[1];
                    if self.f296 <= 0.0 { self.f244 = -1.0; }
                    else { let mut v14 = self.sr / self.f296; if ((2 * self.c80) as f32) <= v14 { v14 = (2 * self.c80) as f32; } self.f244 = v14; }
                    let v16 = (self.f244 + 0.5).floor() as i32;
                    self.tbuf.drain(..h as usize); self.p176 += h;
                    self.hop184 = t.hop();
                    let v7 = self.c80;
                    if v16 <= 0 { self.c88 = v7 >> 2; self.c92 = v7 >> 3; self.c96 = v7 >> 4; if self.c100 > v7 >> 4 { self.c100 = v7 >> 5; } }
                    else { self.set_voiced(self.f244); }
                    if self.p124 + v7.max(self.c88) < self.p176 { done = true; break; }
                }
                if !done { return; }
            }
            let v32 = self.f244 as i32;
            if v32 > 0 && v32 < 2 * self.c156 {
                let v35 = (2 * self.c80).min(2 * v32).max(2 * self.c156);
                self.c88 = v35; let v38 = v35 >> 1; self.c92 = v38; let v40 = v38 >> 1; self.c96 = v40;
                let v39 = (((self.f244 as f64) * 0.0625) as i32).max(self.c156 >> 2).min(v40);
                self.p144 = v38 - v32; self.c100 = v39;
            }
            let w = self.c88;
            if w > self.buf.len() as i32 { return; }
            let mut p128 = self.p124 + self.c92; let v42 = self.c80;
            if w <= v42 >> 3 { self.kkf_n = v42 >> 2; } else if w <= v42 >> 2 { self.kkf_n = v42 >> 1; }
            else if w <= v42 >> 1 { self.kkf_n = v42; } else if w <= v42 { self.kkf_n = 2 * v42; } else if w <= 2 * v42 { self.kkf_n = 4 * v42; }
            let mut peak = -3.4028235e38f32; for &v in &self.buf[..w as usize] { let a = v.abs(); if a > peak { peak = a; } }
            let lag = if peak >= 1e-24 { self.kkf_pick(w) } else { 0 };
            let mut p140 = lag; let mut v45 = lag; self.p144 = lag;
            if self.f300 != 0.0 {
                let v46 = p128 - lag - self.p124;
                if v46 > 4 * self.c156 {
                    let (v47, v49, base) = (self.c92, v46 >> 1, self.c92 - lag); let b = &self.buf;
                    let e0 = b[base as usize]; let mut v51 = (e0 * 1.25) * e0;
                    for j in -v49..v49 { let k = (base + j).max(1) as usize; let e = b[k] * b[k]; if e > v51 { v51 = e; v45 = j; } }
                    if v45 >= -4 { if v45 <= 4 { let v60 = (v45 + v47 - lag).max(1); v45 = v47 - v60; } else { v45 = lag - 2; } } else { v45 = lag + 2; }
                }
                if -self.c92 < v45 && v45 < self.c92 { p140 = v45; }
            }
            p128 -= p140;
            let p188 = p128 - self.p124;
            if p128 - *self.marks.last().unwrap() >= self.c156 >> 2 {
                if p188 > self.buf.len() as i32 { return; }
                let f8 = self.transient(p188 as usize); self.marks.push(p128); self.f8.push(f8);
            }
            self.buf.drain(..(p188.max(0) as usize).min(self.buf.len())); self.p124 = p128;
        }
    }
}

// ================================================================ PSOLA synthesis
struct Syn {
    ch: usize, block: usize, pitch: f32, inv_pitch: f32, inv_stretch: f32, c72: f32, c80: f32,
    xin: Vec<Vec<f32>>, xbase: i64, out: Vec<Vec<f32>>, obase: i64,
    rd: f64, prev: i32, l: i32, rep: i32, w148: i64, w152: i64, produced: i64, r164: i32, received: i64,
    ri: (usize, Vec<usize>), ri2: (usize, Vec<usize>),
}
fn ramp_idx(cache: &mut (usize, Vec<usize>), n: usize) {
    if cache.0 != n || cache.1.len() != n {
        let scale = if n <= 1 { N_RAMP as f32 } else { (N_RAMP - 1) as f32 / (n - 1) as f32 };
        cache.1 = (0..n).map(|i| ((i as f32 * scale) as f64 + 0.5) as usize).collect(); cache.0 = n;
    }
}
fn search_mark(pos: &[i32], start: i32, target: i32) -> i32 {
    let n = pos.len() as i32;
    if start >= n - 1 || n < 2 { return -1; }
    let mut best = (pos[start as usize] - target).abs(); let mut j = start + 1;
    while j < n { let d = (pos[j as usize] - target).abs(); if d >= best { break; } best = d; j += 1; }
    if j == n { return n - 1; }
    if j - 1 > 0 { j - 1 } else { 0 }
}
impl Syn {
    fn new(ch: usize, block: usize) -> Self {
        let mut s = Syn { ch, block, pitch: 1.0, inv_pitch: 1.0, inv_stretch: 1.0, c72: 1.0, c80: 1.0, xin: vec![Vec::new(); ch], xbase: 0,
            out: vec![vec![0.0; 1 << 16]; ch], obase: -(1 << 14), rd: 0.0, prev: 0, l: 0, rep: 1, w148: 0, w152: 0, produced: 0, r164: 0,
            received: 0, ri: (usize::MAX, Vec::new()), ri2: (usize::MAX, Vec::new()) };
        s.set(1.0, 1.0); s
    }
    fn set(&mut self, pitch: f32, stretch: f32) {
        self.pitch = pitch; self.inv_pitch = 1.0 / pitch; self.inv_stretch = 1.0 / stretch;
        let v3 = 1.0f32 / pitch; self.c72 = if v3 <= 1.0 { 1.0 } else { v3 };
        let v2 = 1.0f32 / stretch; self.c80 = if v2 <= 1.0 { 1.0 } else { v2 };
    }
    #[inline] fn src(&self, c: usize, i: i64) -> f32 { let k = i - self.xbase; if k >= 0 && (k as usize) < self.xin[c].len() { self.xin[c][k as usize] } else { 0.0 } }
    fn ensure(&mut self, end_abs: i64) {
        let need = (end_abs - self.obase + 1) as usize;
        if need > self.out[0].len() { let nc = need.max(2 * self.out[0].len()); for o in &mut self.out { o.resize(nc, 0.0); } }
    }
    fn grain(&mut self, l: i32, r: i32, p: i64) {
        self.r164 = r;
        let mut a2 = l;
        if self.pitch < 1.0 { let mut v7 = a2 as f32 * self.pitch; if a2 as f32 <= v7 { v7 = a2 as f32; } a2 = v7 as i32; }
        let mut v9 = r as f32 * self.inv_pitch; if v9 > r as f32 { v9 = r as f32; } let v10 = v9 as i32;
        let zend = ((r as f32 * self.inv_pitch) + 1.5).floor() as i32;
        let s_abs = self.w148 - a2 as i64; self.ensure(s_abs + a2 as i64 + v10.max(zend) as i64 + 1);
        let s0 = (s_abs - self.obase) as usize;
        if a2 > 0 {
            let mut ri = std::mem::take(&mut self.ri); ramp_idx(&mut ri, a2 as usize);
            for c in 0..self.ch { for i in 0..a2 as usize { let v = RAMP[ri.1[i]] * self.src(c, p - a2 as i64 + i as i64); let o = &mut self.out[c][s0 + i]; *o = *o + v; } }
            self.ri = ri;
        }
        let s1 = s0 + a2 as usize;
        if v10 > 0 {
            let mut ri = std::mem::take(&mut self.ri2); ramp_idx(&mut ri, v10 as usize);
            for c in 0..self.ch { for i in 0..v10 as usize { self.out[c][s1 + i] = (1.0 - RAMP[ri.1[i]]) * self.src(c, p + i as i64); } }
            self.ri2 = ri;
        }
        if zend > v10 { for c in 0..self.ch { for v in &mut self.out[c][s1 + v10 as usize..s1 + zend as usize] { *v = 0.0; } } }
        self.w152 = s_abs + a2 as i64; self.w148 = self.w152 + ((r as f32 * self.inv_pitch).floor() as i64);
    }
    fn call(&mut self, pos: &[i32]) -> bool {
        let n = pos.len() as i32; let block_end = self.produced + self.block as i64;
        while self.w152 < block_end {
            let mut idx = search_mark(pos, self.prev, self.rd as i32);
            if idx < 0 && self.rep == 1 { idx = self.prev; }
            if idx < 0 { return false; }
            let mut r = if idx >= 0 && idx < n - 1 { pos[idx as usize + 1] - pos[idx as usize] } else { -1 };
            if r < 0 { r = ((self.l as f32 * self.pitch) + 0.5) as i32; }
            self.grain(self.l, r, pos[idx as usize] as i64);
            self.rep = if idx == self.prev { self.rep + 1 } else { 1 }; self.prev = idx;
            let rout = r as f32 * self.inv_pitch;
            self.l = 0.max((rout + 0.5).floor() as i32);
            self.rd += (rout * self.inv_stretch).floor() as f64;
        }
        true
    }
    fn needed(&self, pos: &[i32], f8: &[f32], block2: i64) -> i32 {
        let n = pos.len() as i32;
        let v1 = self.w152 - self.produced; let mut v29 = v1; let mut v3 = self.rd; let mut v4 = self.prev;
        let mut v12 = (self.w148 - self.w152) as f32; let mut v11 = 0i64;
        if n == 0 { return -1; }
        if v1 >= block2 { return 0; }
        loop {
            let mut v14 = search_mark(pos, v4, v3 as i32);
            let f8v = if v14 >= 0 && v14 < n { f8[v14 as usize] } else { -1.0 };
            if f8v as f64 > 0.7 && v14 == v4 { v14 = v4 + 1; }
            if v14 < 0 { return v14; }
            let v15 = if v14 >= 0 && v14 < n - 1 { pos[v14 as usize + 1] - pos[v14 as usize] } else { -1 };
            if v15 < 0 { return -1; }
            let v23 = (((v15 as f32 * self.c72) * self.c80) as i32) as i64 - self.received + pos[v14 as usize] as i64;
            if v11 < v23 { v11 = v23; }
            v4 = v14;
            let v24 = (v12 as i32) as i64 + v29; v29 = v24;
            let mut v25 = ((v15 as f32 * self.inv_pitch) + 0.5).floor() as i32; if v25 < 2 { v25 = 2; }
            v12 = v25 as f32;
            v3 += ((self.r164 as f32 * self.inv_pitch) * self.inv_stretch).floor() as f64;
            if v24 >= block2 { return if v11 > 0 { v11 as i32 } else { 0 }; }
        }
    }
}

// ================================================================ engine
pub struct E3 { block: usize, ch: usize, stretch: f32, t: Track, a: Ana, s: Syn, inb: Vec<Vec<f32>>, mono: Vec<f32>, outb: Vec<Vec<f32>> }
impl E3 {
    /// sr 32000..63999 (44.1k / 48k), ch >= 1, block 1..=1024 (FL uses 512).
    pub fn new(sr: i32, ch: usize, block: usize) -> Option<Self> {
        if !(32000..64000).contains(&sr) || ch < 1 || block < 1 || block > 1024 { return None; }
        Some(E3 { block, ch, stretch: 1.0, t: Track::new(sr), a: Ana::new(sr as f32), s: Syn::new(ch, block),
                  inb: vec![Vec::new(); ch], mono: Vec::new(), outb: vec![vec![0.0; block]; ch] })
    }
    /// set factors; call before `needed()` each step. pitch: frequency ratio; stretch: length ratio.
    pub fn set(&mut self, pitch: f32, stretch: f32) { self.stretch = stretch; self.s.set(pitch, stretch); }
    /// input frames the next `process` wants (may be 0).
    pub fn needed(&self) -> usize {
        let mut v3 = self.s.needed(&self.a.marks, &self.a.f8, 2 * self.block as i64);
        if v3 < -1 { v3 = -1; }
        if v3 < 0 {
            let c44 = 2048; let c40 = (2 * self.block as i32).max(c44 + (c44 >> 1)).max(2 * c44 + (c44 >> 1));
            let v4 = if self.stretch <= 1.0 { self.stretch } else { 1.0 };
            let mut v5 = (c44 as f32 / v4) + (self.block as i32 + c44) as f32; if v5 <= c40 as f32 { v5 = c40 as f32; }
            v3 = v5 as i32;
        }
        v3 as usize
    }
    /// planar input scratch for channel `c`, length `n`.
    pub fn input(&mut self, c: usize, n: usize) -> &mut [f32] { self.inb[c].resize(n, 0.0); &mut self.inb[c][..n] }
    /// consume `n` frames from the input scratch; true = one block ready in `output`.
    pub fn process(&mut self, n: usize) -> bool {
        self.mono.clear(); self.mono.resize(n, 0.0);
        for c in 0..self.ch { for i in 0..n { self.mono[i] = self.mono[i] + self.inb[c][i]; } }
        let mono = std::mem::take(&mut self.mono); self.a.process(&mut self.t, &mono); self.mono = mono;
        for c in 0..self.ch { self.s.xin[c].extend_from_slice(&self.inb[c][..n]); } self.s.received += n as i64;
        let ok = self.s.call(&self.a.marks);
        if ok {
            let o0 = (self.s.produced - self.s.obase) as usize;
            for c in 0..self.ch { self.outb[c].copy_from_slice(&self.s.out[c][o0..o0 + self.block]); }
            self.s.produced += self.block as i64;
        }
        self.trim();
        ok
    }
    pub fn output(&self, c: usize) -> &[f32] { &self.outb[c] }
    fn trim(&mut self) {
        let (a, s) = (&mut self.a, &mut self.s);
        if a.marks.len() > 1024 { a.marks.drain(..128); a.f8.drain(..128); s.prev -= 128; }
        let keep = a.marks[s.prev.max(0) as usize] as i64 - (1 << 16);
        if keep - s.xbase > (1 << 17) { let k = (keep - s.xbase) as usize; for x in &mut s.xin { x.drain(..k); } s.xbase += k as i64; }
        let drop = s.produced - s.obase - (1 << 14);
        if drop > (1 << 16) { let d = drop as usize; for o in &mut s.out { o.drain(..d); let l = o.len(); o.resize(l + d, 0.0); } s.obase += drop; }
    }
}

/// offline convenience: render whole planar input with per-call factor callbacks (t = input seconds).
pub fn render(chans: &[Vec<f32>], sr: i32, mut pitch: impl FnMut(f64) -> f32, mut stretch: impl FnMut(f64) -> f32, block: usize) -> Vec<Vec<f32>> {
    let ch = chans.len(); let n_in = chans[0].len(); let mut e = E3::new(sr, ch, block).expect("bad args");
    let mut out = vec![Vec::new(); ch]; let mut pos = 0usize;
    while pos < n_in {
        let t = pos as f64 / sr as f64; e.set(pitch(t), stretch(t)); let need = e.needed();
        for c in 0..ch { let b = e.input(c, need); b.iter_mut().for_each(|v| *v = 0.0); let end = (pos + need).min(n_in); if pos < n_in { b[..end - pos].copy_from_slice(&chans[c][pos..end]); } }
        if e.process(need) { for c in 0..ch { out[c].extend_from_slice(e.output(c)); } }
        pos += need;
    }
    out
}
